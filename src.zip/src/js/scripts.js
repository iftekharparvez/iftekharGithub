jQuery( window ).load(function() {
   
       //script to create sticky header 
    jQuery(function(){
        createSticky(jQuery(".sticky-header-area"));
    });
    function createSticky(sticky) {
        if (typeof sticky != "undefined") {

            var pos = sticky.offset().top ,
                win = jQuery(window);

            win.on("scroll", function() {

                if( win.scrollTop() > pos ) {
                    jQuery(".sticky-header-area").css({
                        "display" : "block",
                        "position" : "fixed",
                        "top" : 0,
                        "z-index" : 9999
                    });
                }

                 else {
                    jQuery(".sticky-header-area").css({
                        "display" : "none"
                    });
                }           
            });         
        }
    }  
   
});


//scroll to top using jquery

jQuery(document).ready(function(){

   // jQuery Mobile menu
    jQuery('#nav').slicknav();
   
    
    jQuery(".scrolltotop").click(function(){
        jQuery("html").animate({'scrollTop' : '0'}, "easeInQuint");
        
        return false;	
    });
    
    jQuery(window).scroll(function(){
      
        var scrollBtn = jQuery(window).scrollTop();
    
        if(scrollBtn > 300){
            jQuery(".scrolltotop").fadeIn(1000);
        }
        else {
            jQuery(".scrolltotop").removeAttr("style");
        }
    });

});